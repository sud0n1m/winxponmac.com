#ifndef __I386_H
#define __I386_H

UINTN DasmI386(CHAR16* buffer, UINT32 size, Address addr, UINTN opSize, UINTN addrSize);

#endif // __I386_H